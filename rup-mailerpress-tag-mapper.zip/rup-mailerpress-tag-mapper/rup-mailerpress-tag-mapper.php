<?php
/**
 * Plugin Name:       MailerPress Tag Manager for SureCart
 * Description:       Map SureCart products and prices to MailerPress contact tags on purchase.
 * Tested up to:      7.1.3
 * Requires at least: 6.5
 * Requires PHP:      8.0
 * Version:           1.1.3
 * Author:            Reallyusefulplugins.com
 * Author URI:        https://reallyusefulplugins.com
 * License:           GPL3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       rup-mailerpress-tag-mapper
 * Website:           https://reallyusefulplugins.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RUP_MP_TM_OPTION_ENABLED', 'rup_mp_tm_enabled' );
define( 'RUP_MP_TM_OPTION_MAPPINGS', 'rup_mp_tm_mappings' );
define( 'RUP_MP_TM_OPTION_GLOBAL_DOUBLE_OPTIN', 'rup_mp_tm_global_double_optin' );
define('RUP_MP_TM_VERSION', '1.1.3');
define( 'RUP_MP_TM_PLUGIN_FILE', __FILE__ );
define( 'RUP_MP_TM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Basic debug logger.
 */
function rup_mp_tm_debuglog( string $message ) : void {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		error_log( '[rup-mailerpress-tag-mapper] ' . $message );
	}
}

/**
 * Capability helper.
 */
function rup_mp_tm_get_capability() : string {
	return apply_filters( 'rup_mp_tm_capability', 'manage_sc_shop_settings' );
}

/**
 * Get mappings as array.
 * Returns only saved mappings; new rows are added on demand in the admin UI.
 */
function rup_mp_tm_get_mappings() : array {
	$raw  = get_option( RUP_MP_TM_OPTION_MAPPINGS, '[]' );
	$maps = json_decode( $raw, true );

	if ( ! is_array( $maps ) ) {
		$maps = [];
	}

	$clean = [];

	foreach ( $maps as $map ) {
		if ( ! is_array( $map ) ) {
			continue;
		}

		$clean[] = [
			'product_id'   => sanitize_text_field( $map['product_id'] ?? '' ),
			'price_id'     => sanitize_text_field( $map['price_id'] ?? '' ),
			'tags'         => array_values(
				array_filter(
					array_map(
						'sanitize_text_field',
						(array) ( $map['tags'] ?? [] )
					)
				)
			),
			'enabled'      => ( isset( $map['enabled'] ) && '1' === (string) $map['enabled'] ) ? '1' : '0',
			'double_optin' => ( isset( $map['double_optin'] ) && '1' === (string) $map['double_optin'] ) ? '1' : '0',
		];
	}


	return $clean;
}

/**
 * Save mappings.
 */
function rup_mp_tm_save_mappings( array $maps ) : void {
	$clean = [];

	foreach ( $maps as $map ) {
		if ( ! is_array( $map ) ) {
			continue;
		}

		$row = [
			'product_id'   => sanitize_text_field( $map['product_id'] ?? '' ),
			'price_id'     => sanitize_text_field( $map['price_id'] ?? '' ),
			'tags'         => array_values(
				array_filter(
					array_map(
						'sanitize_text_field',
						(array) ( $map['tags'] ?? [] )
					)
				)
			),
			'enabled'      => ( isset( $map['enabled'] ) && '1' === (string) $map['enabled'] ) ? '1' : '0',
			'double_optin' => ( isset( $map['double_optin'] ) && '1' === (string) $map['double_optin'] ) ? '1' : '0',
		];

		if ( '' === $row['product_id'] && '' === $row['price_id'] && empty( $row['tags'] ) ) {
			continue;
		}

		$clean[] = $row;
	}


	update_option( RUP_MP_TM_OPTION_MAPPINGS, wp_json_encode( array_values( $clean ) ) );
}

/**
 * Get all SureCart products and their available prices.
 *
 * Returns:
 * [
 *   [
 *     'post_id'    => 123,
 *     'title'      => 'Product Name',
 *     'product_id' => 'prod_xxx',
 *     'prices'     => [
 *        [
 *          'id'             => 'price_xxx',
 *          'name'           => 'Single Site',
 *          'display_amount' => 'US$49.00',
 *        ]
 *     ]
 *   ]
 * ]
 */
function rup_mp_tm_get_products_with_prices() : array {
	$products_with_prices = [];

	$posts = get_posts(
		[
			'post_type'      => 'sc_product',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		]
	);

	if ( empty( $posts ) ) {
		return $products_with_prices;
	}

	foreach ( $posts as $post ) {
		$raw = get_post_meta( $post->ID, 'product', true );

		if ( empty( $raw ) ) {
			continue;
		}

		$product = is_string( $raw ) ? maybe_unserialize( $raw ) : $raw;

		if ( empty( $product ) || ! is_array( $product ) ) {
			continue;
		}

		$product_id = isset( $product['id'] ) ? (string) $product['id'] : '';
		$prices     = [];

		if ( ! empty( $product['active_prices'] ) && is_array( $product['active_prices'] ) ) {
			$price_source = $product['active_prices'];
		} elseif (
			! empty( $product['prices'] ) &&
			is_array( $product['prices'] ) &&
			! empty( $product['prices']['data'] ) &&
			is_array( $product['prices']['data'] )
		) {
			$price_source = $product['prices']['data'];
		} else {
			$price_source = [];
		}

		foreach ( $price_source as $price ) {
			if ( ! is_array( $price ) ) {
				continue;
			}

			$price_id   = isset( $price['id'] ) ? (string) $price['id'] : '';
			$price_name = isset( $price['name'] ) ? (string) $price['name'] : '';
			$display    = isset( $price['display_amount'] ) ? (string) $price['display_amount'] : '';

			if ( ! $price_id ) {
				continue;
			}

			$prices[] = [
				'id'             => $price_id,
				'name'           => $price_name,
				'display_amount' => $display,
			];
		}

		if ( empty( $prices ) ) {
			continue;
		}

		$products_with_prices[] = [
			'post_id'    => (int) $post->ID,
			'title'      => get_the_title( $post ),
			'product_id' => $product_id,
			'prices'     => $prices,
		];
	}

	return $products_with_prices;
}

/**
 * Register settings.
 */
add_action(
	'admin_init',
	function () {
		register_setting(
			'rup_mp_tm_group',
			RUP_MP_TM_OPTION_ENABLED,
			[
				'type'              => 'string',
				'sanitize_callback' => static function ( $v ) {
					return '1' === (string) $v ? '1' : '0';
				},
				'default'           => '0',
			]
		);

		register_setting(
			'rup_mp_tm_group',
			RUP_MP_TM_OPTION_GLOBAL_DOUBLE_OPTIN,
			[
				'type'              => 'string',
				'sanitize_callback' => static function ( $v ) {
					return '1' === (string) $v ? '1' : '0';
				},
				'default'           => '0',
			]
		);

		register_setting(
			'rup_mp_tm_group',
			RUP_MP_TM_OPTION_MAPPINGS,
			[
				'type'              => 'string',
				'sanitize_callback' => static function ( $v ) {
					if ( is_string( $v ) && null !== json_decode( $v, true ) ) {
						return $v;
					}

					if ( is_array( $v ) ) {
						$clean = [];

						foreach ( $v as $map ) {
							if ( ! is_array( $map ) ) {
								continue;
							}

							$row = [
								'product_id'   => sanitize_text_field( $map['product_id'] ?? '' ),
								'price_id'     => sanitize_text_field( $map['price_id'] ?? '' ),
								'tags'         => array_values(
									array_filter(
										array_map(
											'sanitize_text_field',
											(array) ( $map['tags'] ?? [] )
										)
									)
								),
								'enabled'      => ( isset( $map['enabled'] ) && '1' === (string) $map['enabled'] ) ? '1' : '0',
								'double_optin' => ( isset( $map['double_optin'] ) && '1' === (string) $map['double_optin'] ) ? '1' : '0',
							];

							if ( '' === $row['product_id'] && '' === $row['price_id'] && empty( $row['tags'] ) ) {
								continue;
							}

							$clean[] = $row;
						}

						if ( empty( $clean ) ) {
							$clean[] = [
								'product_id'   => '',
								'price_id'     => '',
								'tags'         => [],
								'enabled'      => '1',
								'double_optin' => '0',
							];
						}

						return wp_json_encode( $clean );
					}

					return '[]';
				},
				'default'           => '[]',
			]
		);
	}
);

/**
 * Add submenu.
 */
add_action(
	'admin_menu',
	function () {
		add_submenu_page(
			'sc-dashboard',
			__( 'CRM Tag Mapper', 'rup-mailerpress-tag-mapper' ),
			__( 'CRM Tag Mapper', 'rup-mailerpress-tag-mapper' ),
			rup_mp_tm_get_capability(),
			'rup-mailerpress-tag-mapper',
			'rup_mp_tm_render_admin_page'
		);
	},
	99
);

/**
 * Admin assets.
 */
add_action(
	'admin_enqueue_scripts',
	function () {
		if ( ! isset( $_GET['page'] ) || 'rup-mailerpress-tag-mapper' !== $_GET['page'] ) {
			return;
		}

		wp_enqueue_style(
			'select2-css',
			'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css',
			[],
			'4.0.13'
		);

		wp_enqueue_script(
			'select2-js',
			'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.full.min.js',
			[ 'jquery' ],
			'4.0.13',
			true
		);
	}
);

/**
 * Render admin page.
 */
function rup_mp_tm_render_admin_page() {
	if ( ! current_user_can( rup_mp_tm_get_capability() ) && ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$enabled             = get_option( RUP_MP_TM_OPTION_ENABLED, '0' );
	$global_double_optin = get_option( RUP_MP_TM_OPTION_GLOBAL_DOUBLE_OPTIN, '0' );
	$maps                = rup_mp_tm_get_mappings();
	$sc_products         = rup_mp_tm_get_products_with_prices();


	$tags = [];
	if ( class_exists( '\\MailerPress\\Models\\Tags' ) ) {
		$tags = \MailerPress\Models\Tags::getAll();
	}

	?>
	<div class="wrap rup-crm-wrap">
		<h1><?php esc_html_e( 'CRM Tag Mapper', 'rup-mailerpress-tag-mapper' ); ?></h1>
		<p class="rup-crm-lead">
			<?php esc_html_e( 'Map SureCart products or prices to MailerPress tags. You can map an individual price/version or choose all prices for a product.', 'rup-mailerpress-tag-mapper' ); ?>
		</p>

		<form method="post" action="options.php">
			<?php settings_fields( 'rup_mp_tm_group' ); ?>

			<div class="rup-crm-top-card">
				<div class="rup-crm-top-card__content">
					<div>
						<h2><?php esc_html_e( 'Plugin Settings', 'rup-mailerpress-tag-mapper' ); ?></h2>
						<p><?php esc_html_e( 'Enable or disable automatic tag mapping for SureCart purchases.', 'rup-mailerpress-tag-mapper' ); ?></p>
					</div>

					<label class="rup-crm-toggle">
						<input
							type="checkbox"
							name="<?php echo esc_attr( RUP_MP_TM_OPTION_ENABLED ); ?>"
							value="1"
							<?php checked( $enabled, '1' ); ?>
						/>
						<span class="rup-crm-toggle__slider"></span>
						<span class="rup-crm-toggle__label">
							<?php esc_html_e( 'Enable tag mapping', 'rup-mailerpress-tag-mapper' ); ?>
						</span>
					</label>
				</div>

				<div style="margin-top:12px;">
					<label class="rup-crm-checkbox">
						<input
							type="checkbox"
							name="<?php echo esc_attr( RUP_MP_TM_OPTION_GLOBAL_DOUBLE_OPTIN ); ?>"
							value="1"
							<?php checked( $global_double_optin, '1' ); ?>
						/>
						<span><?php esc_html_e( 'Enable global double opt-in', 'rup-mailerpress-tag-mapper' ); ?></span>
					</label>
					<p class="description" style="margin:6px 0 0 24px;">
						<?php esc_html_e( 'If enabled, new matched contacts will be added as pending and sent a MailerPress confirmation email. Existing subscribed contacts remain subscribed.', 'rup-mailerpress-tag-mapper' ); ?>
					</p>
				</div>
			</div>

			<div class="rup-crm-mappings-card">
				<div class="rup-crm-card-header">
					<div>
						<h2><?php esc_html_e( 'Mappings', 'rup-mailerpress-tag-mapper' ); ?></h2>
						<p><?php esc_html_e( 'Choose a product, then either one price/version or all prices for that product.', 'rup-mailerpress-tag-mapper' ); ?></p>
					</div>

					<button type="button" class="button button-secondary" id="rup-crm-add-row-top">
						<?php esc_html_e( 'Add Mapping', 'rup-mailerpress-tag-mapper' ); ?>
					</button>
				</div>

				<div class="rup-crm-toolbar">
					<div class="rup-crm-toolbar__search">
						<label for="rup-crm-filter-search"><?php esc_html_e( 'Search', 'rup-mailerpress-tag-mapper' ); ?></label>
						<input type="text" id="rup-crm-filter-search" placeholder="<?php esc_attr_e( 'Filter by product, price or tag…', 'rup-mailerpress-tag-mapper' ); ?>" />
					</div>

					<div class="rup-crm-toolbar__select">
						<label for="rup-crm-filter-status"><?php esc_html_e( 'Status', 'rup-mailerpress-tag-mapper' ); ?></label>
						<select id="rup-crm-filter-status">
							<option value="all"><?php esc_html_e( 'All rows', 'rup-mailerpress-tag-mapper' ); ?></option>
							<option value="enabled"><?php esc_html_e( 'Enabled only', 'rup-mailerpress-tag-mapper' ); ?></option>
							<option value="disabled"><?php esc_html_e( 'Disabled only', 'rup-mailerpress-tag-mapper' ); ?></option>
						</select>
					</div>

					<div class="rup-crm-toolbar__select">
						<label for="rup-crm-filter-type"><?php esc_html_e( 'Mapping Type', 'rup-mailerpress-tag-mapper' ); ?></label>
						<select id="rup-crm-filter-type">
							<option value="all"><?php esc_html_e( 'All mappings', 'rup-mailerpress-tag-mapper' ); ?></option>
							<option value="product"><?php esc_html_e( 'Whole product', 'rup-mailerpress-tag-mapper' ); ?></option>
							<option value="price"><?php esc_html_e( 'Single price', 'rup-mailerpress-tag-mapper' ); ?></option>
						</select>
					</div>
				</div>

				<div id="rup-crm-mappings-list">
					<?php foreach ( $maps as $i => $m ) : ?>
						<?php
						$product_id_val = isset( $m['product_id'] ) ? (string) $m['product_id'] : '';
						$price_id_val   = isset( $m['price_id'] ) ? (string) $m['price_id'] : '';

						?>
						<div class="rup-crm-mapping-row" data-index="<?php echo esc_attr( $i ); ?>">
                            <button type="button" class="rup-crm-row-summary" aria-expanded="false">
                                <span class="rup-crm-summary-title">Mapping</span>
                                <span class="rup-crm-summary-meta">Product · Price · Tags</span>
                                <span class="rup-crm-summary-state"></span>
                                <span class="rup-crm-summary-edit">Edit <span aria-hidden="true">▾</span></span>
                            </button>
                            <div class="rup-crm-row-details" hidden>
							<div class="rup-crm-row-grid">
								<div class="rup-crm-field">
									<label><?php esc_html_e( 'Product', 'rup-mailerpress-tag-mapper' ); ?></label>
									<select
										class="rup-crm-product-select"
										name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[<?php echo esc_attr( $i ); ?>][product_id]"
									>
										<option value=""><?php esc_html_e( '— Select product —', 'rup-mailerpress-tag-mapper' ); ?></option>
										<?php foreach ( $sc_products as $product ) : ?>
											<option
												value="<?php echo esc_attr( $product['product_id'] ); ?>"
												data-post-id="<?php echo esc_attr( $product['post_id'] ); ?>"
												<?php selected( $product_id_val, $product['product_id'] ); ?>
											>
												<?php echo esc_html( $product['title'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>

								<div class="rup-crm-field">
									<label><?php esc_html_e( 'Price / Version', 'rup-mailerpress-tag-mapper' ); ?></label>
									<select
										class="rup-crm-price-select"
										name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[<?php echo esc_attr( $i ); ?>][price_id]"
										<?php disabled( empty( $sc_products ) ); ?>
									>
										<option value=""><?php esc_html_e( '— Select price / version —', 'rup-mailerpress-tag-mapper' ); ?></option>
									</select>
									<p class="description rup-crm-price-description"></p>
								</div>

								<div class="rup-crm-field rup-crm-field--tags">
									<label><?php esc_html_e( 'MailerPress Tags', 'rup-mailerpress-tag-mapper' ); ?></label>
									<select
										class="rup-crm-tag-select"
										name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[<?php echo esc_attr( $i ); ?>][tags][]"
										multiple="multiple"
									>
										<?php foreach ( $tags as $t ) : ?>
											<option
												value="<?php echo esc_attr( $t->tag_id ); ?>"
												<?php selected( in_array( (string) $t->tag_id, array_map('strval',(array)($m['tags'] ?? [])), true ) ); ?>
											>
												<?php echo esc_html( $t->name ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>

							<div class="rup-crm-row-actions">
								<label class="rup-crm-checkbox">
									<input
										type="checkbox"
										class="rup-crm-enabled-checkbox"
										name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[<?php echo esc_attr( $i ); ?>][enabled]"
										value="1"
										<?php checked( ( $m['enabled'] ?? '0' ), '1' ); ?>
									/>
									<span><?php esc_html_e( 'Enabled', 'rup-mailerpress-tag-mapper' ); ?></span>
								</label>

								<label class="rup-crm-checkbox">
									<input
										type="checkbox"
										class="rup-crm-double-optin-checkbox"
										name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[<?php echo esc_attr( $i ); ?>][double_optin]"
										value="1"
										<?php checked( ( $m['double_optin'] ?? '0' ), '1' ); ?>
									/>
									<span><?php esc_html_e( 'Double opt-in', 'rup-mailerpress-tag-mapper' ); ?></span>
								</label>

								<button type="button" class="button-link-delete rup-crm-remove-row">
									<?php esc_html_e( 'Delete', 'rup-mailerpress-tag-mapper' ); ?>
								</button>
							</div>
                            </div><!-- .rup-crm-row-details -->
						</div>
					<?php endforeach; ?>
				</div>

				<div class="rup-crm-card-footer">
					<button type="button" class="button button-secondary" id="rup-crm-add-row-bottom">
						<?php esc_html_e( 'Add Mapping', 'rup-mailerpress-tag-mapper' ); ?>
					</button>
				</div>

				<p class="description rup-crm-help">
					<?php esc_html_e( 'Select a product, then choose a specific price/version or “All prices for this product”. On purchase, matching MailerPress tags will be applied automatically. If global or row-level double opt-in is enabled, new contacts will be added as pending and sent the double opt-in email.', 'rup-mailerpress-tag-mapper' ); ?>
				</p>
			</div>

			<?php submit_button( __( 'Save Mappings', 'rup-mailerpress-tag-mapper' ) ); ?>
		</form>
	</div>

	<style>
        /*
         * Scroll recovery, scoped to this plugin's admin page.
         * Some admin themes/plugins leave html/body or WP wrappers with
         * overflow:hidden or a viewport-height cap. This causes a long
         * mapping screen to appear unscrollable without any console errors.
         * The stylesheet below is only printed while this page is rendered.
         */
        html, body.wp-admin {
            overflow-x: hidden !important;
            overflow-y: auto !important;
            height: auto !important;
            min-height: 100% !important;
            max-height: none !important;
        }
        #wpwrap, #wpcontent, #wpbody, #wpbody-content {
            overflow: visible !important;
            height: auto !important;
            max-height: none !important;
        }
        #wpbody-content::after { content: ""; display: block; clear: both; }
		.rup-crm-wrap {
			max-width: 1280px;
		}

		.rup-crm-wrap h1 {
			font-size: 28px;
			font-weight: 700;
			line-height: 1.2;
			margin-bottom: 8px;
			color: #0f172a;
		}

		.rup-crm-lead {
			font-size: 14px;
			color: #475569;
			margin-bottom: 18px;
		}

		.rup-crm-top-card,
		.rup-crm-mappings-card {
			background: #fff;
			border: 1px solid #e2e8f0;
			border-radius: 18px;
			box-shadow: 0 18px 40px rgba(15, 23, 42, 0.05);
			margin-bottom: 20px;
		}

		.rup-crm-top-card {
			padding: 22px 24px;
		}

		.rup-crm-top-card__content {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 20px;
			flex-wrap: wrap;
		}

		.rup-crm-top-card h2,
		.rup-crm-card-header h2 {
			margin: 0 0 6px;
			font-size: 18px;
			font-weight: 700;
			color: #0f172a;
		}

		.rup-crm-top-card p,
		.rup-crm-card-header p {
			margin: 0;
			color: #64748b;
			font-size: 13px;
		}

		.rup-crm-card-header {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 16px;
			padding: 22px 24px 0;
			flex-wrap: wrap;
		}

		.rup-crm-toolbar {
			display: grid;
			grid-template-columns: 2fr 1fr 1fr;
			gap: 14px;
			padding: 18px 24px 0;
		}

		.rup-crm-toolbar label {
			display: block;
			font-size: 12px;
			font-weight: 600;
			color: #334155;
			margin-bottom: 7px;
		}

		.rup-crm-toolbar input,
		.rup-crm-toolbar select {
			width: 100%;
			min-height: 40px;
			border: 1px solid #cbd5e1;
			border-radius: 10px;
			background: #f8fafc;
			padding: 8px 12px;
			box-sizing: border-box;
			color: #0f172a;
		}

		#rup-crm-mappings-list {
			padding: 20px 24px 10px;
		}

		.rup-crm-mapping-row {
			border: 1px solid #e2e8f0;
			background: linear-gradient(180deg, #ffffff 0%, #fbfdff 100%);
			border-radius: 16px;
			padding: 18px;
			margin-bottom: 16px;
			box-shadow: 0 10px 28px rgba(15, 23, 42, 0.04);
		}

		.rup-crm-mapping-row.rup-crm-hidden {
			display: none;
		}

		.rup-crm-row-grid {
			display: grid;
			grid-template-columns: 1.2fr 1.2fr 1.6fr;
			gap: 14px;
		}

		.rup-crm-field {
			min-width: 0;
		}

		.rup-crm-field label {
			display: block;
			font-size: 12px;
			font-weight: 600;
			color: #334155;
			margin-bottom: 7px;
		}

		.rup-crm-field input[type="text"],
		.rup-crm-field select {
			width: 100%;
			max-width: 100%;
			min-height: 40px;
			border: 1px solid #cbd5e1;
			border-radius: 10px;
			background: #f8fafc;
			padding: 8px 12px;
			box-sizing: border-box;
			color: #0f172a;
			transition: border-color .18s ease, box-shadow .18s ease, background .18s ease;
		}

		.rup-crm-field input[type="text"]:focus,
		.rup-crm-field select:focus,
		.rup-crm-toolbar input:focus,
		.rup-crm-toolbar select:focus {
			outline: none;
			border-color: #2563eb;
			background: #fff;
			box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.10);
		}

		.rup-crm-field--tags .select2-container {
			width: 100% !important;
		}

		.rup-crm-field--tags .select2-container--default .select2-selection--multiple {
			min-height: 40px;
			border-radius: 10px;
			border: 1px solid #cbd5e1;
			background: #f8fafc;
			padding: 3px 6px;
		}

		.rup-crm-price-description {
			min-height: 18px;
			margin: 6px 0 0;
			font-size: 12px;
			color: #64748b;
		}

		.rup-crm-row-actions {
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-top: 14px;
			padding-top: 12px;
			border-top: 1px solid #edf2f7;
			gap: 12px;
			flex-wrap: wrap;
		}

		.rup-crm-checkbox {
			display: inline-flex;
			align-items: center;
			gap: 8px;
			font-weight: 500;
			color: #334155;
		}

		.rup-crm-help {
			padding: 0 24px 24px;
			color: #64748b;
		}

		.rup-crm-card-footer {
			padding: 0 24px 20px;
		}

		.rup-crm-toggle {
			display: inline-flex;
			align-items: center;
			gap: 12px;
			cursor: pointer;
			user-select: none;
		}

		.rup-crm-toggle input {
			position: absolute;
			opacity: 0;
			pointer-events: none;
		}

		.rup-crm-toggle__slider {
			position: relative;
			display: inline-block;
			width: 48px;
			height: 28px;
			border-radius: 999px;
			background: #cbd5e1;
			transition: background .2s ease;
			flex: 0 0 auto;
		}

		.rup-crm-toggle__slider::after {
			content: '';
			position: absolute;
			top: 3px;
			left: 3px;
			width: 22px;
			height: 22px;
			border-radius: 50%;
			background: #fff;
			box-shadow: 0 2px 8px rgba(0, 0, 0, 0.16);
			transition: transform .2s ease;
		}

		.rup-crm-toggle input:checked + .rup-crm-toggle__slider {
			background: #2563eb;
		}

		.rup-crm-toggle input:checked + .rup-crm-toggle__slider::after {
			transform: translateX(20px);
		}

		.rup-crm-toggle__label {
			font-weight: 600;
			color: #0f172a;
		}

		.rup-crm-row-spacer {
			display: inline-block;
			min-width: 1px;
			min-height: 1px;
		}

		@media (max-width: 1100px) {
			.rup-crm-toolbar {
				grid-template-columns: 1fr;
			}

			.rup-crm-row-grid {
				grid-template-columns: 1fr;
			}
		}

		@media (max-width: 640px) {
			.rup-crm-top-card__content,
			.rup-crm-card-header,
			.rup-crm-row-actions {
				flex-direction: column;
				align-items: flex-start;
			}
		}
        /* Compact mapping summaries: no forced page height or scroll lock. */
        .rup-crm-wrap, .rup-crm-mappings-card, #rup-crm-mappings-list {
            overflow: visible;
            height: auto;
            max-height: none;
        }
        .rup-crm-mapping-row { padding: 0; overflow: visible; }
        .rup-crm-row-summary {
            display: flex; align-items: center; gap: 12px; width: 100%;
            padding: 14px 16px; background: transparent; border: 0;
            text-align: left; cursor: pointer; color: #0f172a;
        }
        .rup-crm-row-summary:hover { background: #f1f5f9; border-radius: 15px; }
        .rup-crm-row-summary:focus-visible { outline: 3px solid #2563eb; outline-offset: 2px; }
        .rup-crm-summary-title { flex: 1 1 30%; min-width: 100px; font-weight: 700; overflow-wrap: anywhere; }
        .rup-crm-summary-meta { flex: 2 1 45%; min-width: 100px; font-size: 12px; color: #475569; overflow-wrap: anywhere; }
        .rup-crm-summary-state { font-size: 12px; font-weight: 600; color: #64748b; white-space: nowrap; }
        .rup-crm-summary-edit { font-size: 13px; font-weight: 600; color: #2563eb; white-space: nowrap; }
        .rup-crm-row-details { padding: 0 18px 18px; border-top: 1px solid #edf2f7; }
        .rup-crm-row-details[hidden] { display: none !important; }
        .rup-crm-row-grid { padding-top: 16px; }
        @media (max-width: 680px) {
            .rup-crm-row-summary { flex-wrap: wrap; }
            .rup-crm-summary-title { flex-basis: 65%; }
            .rup-crm-summary-meta { flex-basis: 100%; order: 4; }
        }

	</style>

	<script>
		jQuery(function($) {
			const products = <?php echo wp_json_encode( $sc_products ); ?> || [];
			const productMapByProductId = {};

			products.forEach(function(product) {
				productMapByProductId[String(product.product_id)] = product;
			});

            function refreshRowSummary($row) {
                const product = $row.find('.rup-crm-product-select option:selected').text().trim();
                const price = $row.find('.rup-crm-price-select option:selected').text().trim();
                const tags = $row.find('.rup-crm-tag-select option:selected').map(function() {
                    return $(this).text().trim();
                }).get();
                const isEnabled = $row.find('.rup-crm-enabled-checkbox').is(':checked');
                const doi = $row.find('.rup-crm-double-optin-checkbox').is(':checked');
                const selectedProduct = $row.find('.rup-crm-product-select').val();
                $row.find('.rup-crm-summary-title').text(selectedProduct ? product : 'New mapping');
                const p = price && $row.find('.rup-crm-price-select').val() ? price : 'Choose price';
                $row.find('.rup-crm-summary-meta').text(p + ' · ' + (tags.length ? tags.join(', ') : 'No tags selected'));
                $row.find('.rup-crm-summary-state').text((isEnabled ? 'Enabled' : 'Disabled') + (doi ? ' · Double opt-in' : ''));
            }

            function setRowExpanded($row, expanded) {
                $row.find('.rup-crm-row-details').prop('hidden', !expanded);
                $row.find('.rup-crm-row-summary').attr('aria-expanded', expanded ? 'true' : 'false');
                $row.find('.rup-crm-summary-edit').html(expanded ? 'Close <span aria-hidden="true">▴</span>' : 'Edit <span aria-hidden="true">▾</span>');
            }

            $('#rup-crm-mappings-list').on('click', '.rup-crm-row-summary', function() {
                const $row = $(this).closest('.rup-crm-mapping-row');
                setRowExpanded($row, $(this).attr('aria-expanded') !== 'true');
            });

			function initTagSelect(context) {
				$(context).find('.rup-crm-tag-select').select2({
					placeholder: 'Search & select tags…',
					width: '100%',
					allowClear: true,
					minimumResultsForSearch: 0
				});
			}

			function buildPriceOptions($row, productId) {
				const $priceSelect = $row.find('.rup-crm-price-select');
				const $desc = $row.find('.rup-crm-price-description');

				$priceSelect.empty().append(
					$('<option>', {
						value: '',
						text: '— Select price / version —'
					})
				);

				$desc.text('');

				const product = productMapByProductId[String(productId)];
				if (!product || !product.prices || !product.prices.length) {
					$priceSelect.prop('disabled', true);
					return;
				}

				$priceSelect.append(
					$('<option>', {
						value: '__all__',
						text: 'All prices for this product'
					})
				);

				product.prices.forEach(function(price) {
					let label = price.name || price.id;
					if (price.display_amount) {
						label += ' (' + price.display_amount + ')';
					}

					$priceSelect.append(
						$('<option>', {
							value: price.id,
							text: label
						})
					);
				});

				$priceSelect.prop('disabled', false);
			}

			function updateDescription($row) {
				const productId = $row.find('.rup-crm-product-select').val();
				const priceId = $row.find('.rup-crm-price-select').val();
				const $desc = $row.find('.rup-crm-price-description');

				const product = productMapByProductId[String(productId)];
				if (!product || !productId) {
					$desc.text('');
					return;
				}

				if (priceId === '__all__') {
					$desc.text(product.title + ' – All prices for this product');
					return;
				}

				if (!priceId) {
					$desc.text('');
					return;
				}

				const match = (product.prices || []).find(function(price) {
					return String(price.id) === String(priceId);
				});

				if (!match) {
					$desc.text('');
					return;
				}

				let text = product.title + ' – ' + (match.name || '');
				if (match.display_amount) {
					text += ' (' + match.display_amount + ')';
				}
				$desc.text(text);
			}

			function getRowSearchText($row) {
				const productText = $row.find('.rup-crm-product-select option:selected').text() || '';
				const priceText = $row.find('.rup-crm-price-select option:selected').text() || '';
				const tagsText = $row.find('.rup-crm-tag-select option:selected').map(function() {
					return $(this).text();
				}).get().join(' ');
				return (productText + ' ' + priceText + ' ' + tagsText).toLowerCase();
			}

			function getRowType($row) {
				const priceId = $row.find('.rup-crm-price-select').val();
				if (priceId === '__all__') {
					return 'product';
				}
				if (priceId) {
					return 'price';
				}
				return 'all';
			}

			function applyFilters() {
				const search = ($('#rup-crm-filter-search').val() || '').toLowerCase().trim();
				const status = $('#rup-crm-filter-status').val();
				const type = $('#rup-crm-filter-type').val();

				$('#rup-crm-mappings-list .rup-crm-mapping-row').each(function() {
					const $row = $(this);
					const rowText = getRowSearchText($row);
					const enabled = $row.find('.rup-crm-enabled-checkbox').is(':checked');
					const rowType = getRowType($row);

					let show = true;

					if (search && rowText.indexOf(search) === -1) {
						show = false;
					}

					if (status === 'enabled' && !enabled) {
						show = false;
					}

					if (status === 'disabled' && enabled) {
						show = false;
					}

					if (type === 'product' && rowType !== 'product') {
						show = false;
					}

					if (type === 'price' && rowType !== 'price') {
						show = false;
					}

					$row.toggleClass('rup-crm-hidden', !show);
                    refreshRowSummary($row);
				});
			}

			function bindRow($row) {
				const $productSelect = $row.find('.rup-crm-product-select');
				const $priceSelect = $row.find('.rup-crm-price-select');

				$productSelect.off('change.rupcrm').on('change.rupcrm', function() {
					const productId = $(this).val();
					buildPriceOptions($row, productId);
					$priceSelect.val('');
					updateDescription($row);
					applyFilters();
				});

				$priceSelect.off('change.rupcrm').on('change.rupcrm', function() {
					updateDescription($row);
					applyFilters();
				});

				$row.find('.rup-crm-enabled-checkbox').off('change.rupcrm').on('change.rupcrm', function() {
					applyFilters();
				});

				$row.find('.rup-crm-tag-select').off('change.rupcrm').on('change.rupcrm', function() {
					applyFilters();
				});

				$row.find('.rup-crm-remove-row').off('click.rupcrm').on('click.rupcrm', function() {
					$row.remove();
					applyFilters();
				});

				const existingProductId = ($productSelect.val() || '').trim();
				const existingPriceId = ($priceSelect.attr('data-stored-price-id') || $priceSelect.val() || '').trim();

				if (existingProductId) {
					buildPriceOptions($row, existingProductId);

					if (existingPriceId) {
						$priceSelect.val(existingPriceId);
					}
					updateDescription($row);
				}

				initTagSelect($row);
			}

			$('#rup-crm-mappings-list .rup-crm-mapping-row').each(function() {
				const $row = $(this);
				const storedPriceId = <?php echo wp_json_encode( array_map( static function( $map ) { return (string) ( $map['price_id'] ?? '' ); }, $maps ) ); ?>[$row.data('index')] || '';
				$row.find('.rup-crm-price-select').attr('data-stored-price-id', storedPriceId);
				bindRow($row);
			});

			let nextMappingIndex = <?php echo (int) count( $maps ); ?>;

			function addRow() {
				const nextIndex = nextMappingIndex++;

				const tagsHtml = <?php
				ob_start();
				?>
				<select class="rup-crm-tag-select" name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[__INDEX__][tags][]" multiple="multiple">
					<?php foreach ( $tags as $t ) : ?>
						<option value="<?php echo esc_attr( $t->tag_id ); ?>"><?php echo esc_html( $t->name ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php
				echo wp_json_encode( trim( ob_get_clean() ) );
				?>;

				const productsHtml = <?php
				ob_start();
				?>
				<option value=""><?php esc_html_e( '— Select product —', 'rup-mailerpress-tag-mapper' ); ?></option>
				<?php foreach ( $sc_products as $product ) : ?>
					<option value="<?php echo esc_attr( $product['product_id'] ); ?>" data-post-id="<?php echo esc_attr( $product['post_id'] ); ?>">
						<?php echo esc_html( $product['title'] ); ?>
					</option>
				<?php endforeach; ?>
				<?php
				echo wp_json_encode( trim( ob_get_clean() ) );
				?>;

				let rowHtml = `
					<div class="rup-crm-mapping-row" data-index="${nextIndex}">
                        <button type="button" class="rup-crm-row-summary" aria-expanded="true">
                            <span class="rup-crm-summary-title">New mapping</span>
                            <span class="rup-crm-summary-meta">Choose product, price and tags</span>
                            <span class="rup-crm-summary-state"></span>
                            <span class="rup-crm-summary-edit">Close <span aria-hidden="true">▴</span></span>
                        </button>
                        <div class="rup-crm-row-details">
						<div class="rup-crm-row-grid">
							<div class="rup-crm-field">
								<label><?php echo esc_js( __( 'Product', 'rup-mailerpress-tag-mapper' ) ); ?></label>
								<select
									class="rup-crm-product-select"
									name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[${nextIndex}][product_id]"
								>
									${productsHtml}
								</select>
							</div>

							<div class="rup-crm-field">
								<label><?php echo esc_js( __( 'Price / Version', 'rup-mailerpress-tag-mapper' ) ); ?></label>
								<select
									class="rup-crm-price-select"
									name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[${nextIndex}][price_id]"
									<?php echo empty( $sc_products ) ? 'disabled="disabled"' : ''; ?>
								>
									<option value=""><?php echo esc_js( __( '— Select price / version —', 'rup-mailerpress-tag-mapper' ) ); ?></option>
								</select>
								<p class="description rup-crm-price-description"></p>
							</div>

							<div class="rup-crm-field rup-crm-field--tags">
								<label><?php echo esc_js( __( 'MailerPress Tags', 'rup-mailerpress-tag-mapper' ) ); ?></label>
								${tagsHtml.replace(/__INDEX__/g, nextIndex)}
							</div>
						</div>

						<div class="rup-crm-row-actions">
							<label class="rup-crm-checkbox">
								<input
									type="checkbox"
									class="rup-crm-enabled-checkbox"
									name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[${nextIndex}][enabled]"
									value="1"
									checked="checked"
								/>
								<span><?php echo esc_js( __( 'Enabled', 'rup-mailerpress-tag-mapper' ) ); ?></span>
							</label>

							<label class="rup-crm-checkbox">
								<input
									type="checkbox"
									class="rup-crm-double-optin-checkbox"
									name="<?php echo esc_attr( RUP_MP_TM_OPTION_MAPPINGS ); ?>[${nextIndex}][double_optin]"
									value="1"
								/>
								<span><?php echo esc_js( __( 'Double opt-in', 'rup-mailerpress-tag-mapper' ) ); ?></span>
							</label>

							<button type="button" class="button-link-delete rup-crm-remove-row">
								<?php echo esc_js( __( 'Delete', 'rup-mailerpress-tag-mapper' ) ); ?>
							</button>
						</div>
                        </div><!-- .rup-crm-row-details -->
						</div>
					`;

				const $row = $(rowHtml);
				$('#rup-crm-mappings-list').append($row);
				bindRow($row);

				// Clear toolbar filters: the new, unsaved row should never be hidden.
				$('#rup-crm-filter-search').val('');
				$('#rup-crm-filter-status, #rup-crm-filter-type').val('all');
				applyFilters();
				setRowExpanded($row, true);

				// Works for either Add Mapping button, including the top button.
				// Scroll after layout/select2 initialization, then focus product selector.
				window.requestAnimationFrame(function() {
					$row[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
					window.setTimeout(function() {
						$row.find('.rup-crm-product-select')[0]?.focus({ preventScroll: true });
					}, 350);
				});
			}

			$('#rup-crm-add-row-top, #rup-crm-add-row-bottom').on('click', function() {
				addRow();
			});

			$('#rup-crm-filter-search, #rup-crm-filter-status, #rup-crm-filter-type').on('input change', function() {
				applyFilters();
			});

			applyFilters();
		});
	</script>

	<script>
		jQuery(function($) {
			const storedPriceIds = <?php echo wp_json_encode( array_map( static function( $map ) { return (string) ( $map['price_id'] ?? '' ); }, $maps ) ); ?>;

			$('#rup-crm-mappings-list .rup-crm-mapping-row').each(function() {
				const index = parseInt($(this).attr('data-index'), 10);
				const storedPriceId = storedPriceIds[index] || '';
				$(this).find('.rup-crm-price-select').attr('data-stored-price-id', storedPriceId);
			});
		});
	</script>
	<?php
}

/**
 * Extract purchased line items from checkout/order object.
 */
function rup_mp_tm_get_checkout_line_items( $checkout ) : array {
	if ( ! $checkout || empty( $checkout->line_items ) || empty( $checkout->line_items->data ) || ! is_array( $checkout->line_items->data ) ) {
		return [];
	}

	return $checkout->line_items->data;
}

/**
 * Determine whether a line item matches a mapping.
 *
 * Mapping rules:
 * - product_id + price_id="__all__" => all prices for that product
 * - product_id + exact price_id     => specific price only
 * - legacy fallback                 => exact price_id match
 */
function rup_mp_tm_line_item_matches_mapping( $item, array $mapping ) : bool {
	$item_price_id   = isset( $item->price_id ) ? (string) $item->price_id : '';
	$item_product_id = '';

	if ( isset( $item->price ) && is_object( $item->price ) && ! empty( $item->price->product ) ) {
		if ( is_object( $item->price->product ) && ! empty( $item->price->product->id ) ) {
			$item_product_id = (string) $item->price->product->id;
		} elseif ( is_string( $item->price->product ) ) {
			$item_product_id = (string) $item->price->product;
		}
	}

	if ( ! $item_product_id && isset( $item->product_id ) ) {
		$item_product_id = (string) $item->product_id;
	}

	$mapping_product_id = isset( $mapping['product_id'] ) ? (string) $mapping['product_id'] : '';
	$mapping_price_id   = isset( $mapping['price_id'] ) ? (string) $mapping['price_id'] : '';

	if ( $mapping_product_id && '__all__' === $mapping_price_id ) {
		return $item_product_id && $item_product_id === $mapping_product_id;
	}

	if ( $mapping_product_id && $mapping_price_id && '__all__' !== $mapping_price_id ) {
		if ( $item_product_id && $item_product_id !== $mapping_product_id ) {
			return false;
		}
		return $item_price_id && $item_price_id === $mapping_price_id;
	}

	if ( $mapping_price_id && '__all__' !== $mapping_price_id ) {
		return $item_price_id && $item_price_id === $mapping_price_id;
	}

	return false;
}

/**
 * Determine desired contact handling for matched mappings.
 *
 * Returns:
 * [
 *   'tags' => array,
 *   'requires_double_optin' => bool,
 * ]
 */
function rup_mp_tm_collect_matched_tags_and_optin_flags( array $line_items, array $maps ) : array {
	$to_apply              = [];
	$requires_double_optin = ( '1' === get_option( RUP_MP_TM_OPTION_GLOBAL_DOUBLE_OPTIN, '0' ) );

	foreach ( $line_items as $item ) {
		foreach ( $maps as $m ) {
			if ( rup_mp_tm_line_item_matches_mapping( $item, $m ) ) {
				foreach ( (array) ( $m['tags'] ?? [] ) as $slug ) {
					$slug = sanitize_text_field( $slug );
					if ( $slug ) {
						$to_apply[] = $slug;
					}
				}

				if ( isset( $m['double_optin'] ) && '1' === (string) $m['double_optin'] ) {
					$requires_double_optin = true;
				}
			}
		}
	}

	return [
		'tags'                  => array_values( array_unique( $to_apply ) ),
		'requires_double_optin' => $requires_double_optin,
	];
}

/**
 * Build contact payload safely.
 *
 * New contacts:
 * - pending if global/per-row double opt-in applies
 * - otherwise subscribed
 *
 * Existing contacts:
 * - keep existing status
 * - never downgrade subscribed users back to pending
 * - do not alter bounced/complained/spammed/unsubscribed/transactional statuses
 */
/**
 * Apply matching tag IDs via MailerPress's own upsert service.
 * Never overwrite an existing subscriber's consent or subscription status.
 */
function rup_mp_tm_apply_purchase( $checkout ) {
    if ( '1' !== get_option(RUP_MP_TM_OPTION_ENABLED, '0') || !class_exists('\\MailerPress\\Services\\ContactUpsertService') ) return;
    $maps = json_decode(get_option(RUP_MP_TM_OPTION_MAPPINGS, '[]'), true);
    if (!is_array($maps)) return;
    $maps = array_filter($maps, static fn($m) => !empty($m['enabled']) && (string)$m['enabled'] === '1');
    if (!$maps) return;
    $email = sanitize_email((string)($checkout->email ?? ''));
    if (!is_email($email)) return;
    $items = rup_mp_tm_get_checkout_line_items($checkout);
    if (!$items) return;
    $matched = rup_mp_tm_collect_matched_tags_and_optin_flags($items,$maps);
    $tag_ids = array_values(array_unique(array_filter(array_map('absint', $matched['tags']))));
    if (!$tag_ids) return;
    // Note: Checkout emails aren't by themselves proof of marketing opt-in.
    // New contacts are kept pending, even if the old mapper was configured otherwise.
    // Existing status and name fields are preserved.
    $existing = (new \MailerPress\Models\Contacts())->getContactByEmail($email);
    $payload = [
        'email' => $email,
        'tag_ids' => $tag_ids,
        'tag_mode' => 'append',
        'update_contact_fields' => false,
        'assign_default_list' => false,
    ];
    if (!$existing) {
        $payload['contactStatus'] = 'pending';
        $payload['opt_in_source'] = 'surecart_purchase_tag_mapping';
    }
    try {
        $result = (new \MailerPress\Services\ContactUpsertService())->upsert($payload);
        if (empty($result['success'])) rup_mp_tm_debuglog('MailerPress upsert failed: ' . wp_json_encode($result));
        // Initial confirmation emails are deliberately NOT sent automatically:
        // the shop may not have obtained newsletter opt-in consent.
        // If your checkout collects explicit consent, connect its verified consent
        // to your existing confirmation workflow separately.
    } catch (\Throwable $e) {
        rup_mp_tm_debuglog('MailerPress error: '.$e->getMessage());
    }
}
add_action('surecart/checkout_confirmed', 'rup_mp_tm_apply_purchase', 10, 1);
add_action('surelywp_tk_lm_on_new_order_create', 'rup_mp_tm_apply_purchase', 10, 1);

// ──────────────────────────────────────────────────────────────────────────
// Updater bootstrap
// ──────────────────────────────────────────────────────────────────────────
add_action(
    'plugins_loaded',
    function() {
        $updater_file = RUP_MP_TM_PLUGIN_DIR . 'inc/updater.php';

        if ( ! file_exists( $updater_file ) ) {
            return;
        }

        require_once $updater_file;

        $updater_config = array(
            'vendor'      => 'rup',
            'plugin_file' => plugin_basename( RUP_MP_TM_PLUGIN_FILE ),
            'slug'        => 'rup-mailerpress-tag-mapper',
            'name'        => 'rup mailpress tag mapper',
            'version'     => RUP_MP_TM_VERSION,
            'key'         => '',
            'server'      => 'https://raw.githubusercontent.com/stingray82/mailerpress-tag-manager-for-surecart/main/uupd/index.json',
        );

        \RUP\Updater\Updater_V2::register( $updater_config );
    },
    20
);
